<?php
namespace Drupal\users\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Routing;
use Drupal\paragraphs\Entity\Paragraph;


class CreditPersonsForm extends ConfigFormBase
{
  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames()
  {
    return array('general.credit_user_form');
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId()
  {
    return 'credit_users_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm($form, FormStateInterface $form_state)
  {
    $configs = $this->config('general.credit_users_form');
    $num_user = $form_state->get('num_user');

    if ($num_user === null)
    {
      $users = $form_state->set('num_user', 1);
      $num_user = 1;
    }
    
    $form['#tree'] = true;
    $form['site_credits'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('Site managers'),
      '#prefix' => '<div id="siteCreditsWrapper">',
      '#suffix' => '</div>',
    );

    

    for($i = 0; $i < $num_user; $i++) {
      $num = $i + 1;
      
      $form['site_credits']["users{$num}"] = array(
        '#type' => 'fieldset',
        '#title' => $this->t("User #{$num}"),
        '#prefix' => "<div id=\"user-{$num}\">",
        '#suffix' => '</div>',
      );

      
      $form['site_credits']["users{$num}"]['field_uid'] = array(
        '#type' => 'textfield',
        '#title' => $this->t('User Id'),
      );
  
      $form['site_credits']["users{$num}"]['field_role'] = array(
        '#type' => 'select',
        '#title' => $this->t('User Role'),
       '#options' => [
          'Admin' => 'Admin',
          'Member' => 'Member',
          'Subscriber' => 'Subscriber',
       ],
       //'#options' => $this->get_role_options(),
      );
  
      $form['site_credits']["users{$num}"]['field_status'] = array(
        '#type' => 'select',
        '#title' => $this->t('User status'),
        '#options' => [
         'Pending' => 'Pending',
         'Approved' => 'Approved',
         'Blocked' => 'Blocked',
      ],
      );
  
      $form['site_credits']["users{$num}"]['field_user_emailid'] = array(
        '#type' => 'textfield',
        '#title' => $this->t('EmailId'),
      );

      $form['site_credits']["users{$num}"]['actions'] = array(
        '#type' => 'actions',
      );

      if ($num_user > 1)
      {
        $form['site_credits']["users{$num}"]['actions']['remove_user'] = array(
          '#type' => 'submit',
          '#value' => $this->t("Remove user"),
          '#submit' => ['::removeCallback'],
          '#ajax' => array(
            'callback' => '::addmoreCallback',
            'wrapper' => 'siteCreditsWrapper',
          ),
        );
      }
    }

    $form['site_credits']['actions'] = array(
      '#type' => 'actions',
    );

    $form['site_credits']['actions']['add_user'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Add one more'),
      '#submit' => ['::addOne'],
      '#ajax' => array(
        'callback' => '::addmoreCallback',
        'wrapper' => 'siteCreditsWrapper',
      ),
      '#button_type' => 'default'
    );

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    );
  
    return $form;
  }

  /**
   * 
   */
  public function addmoreCallback(array &$form, FormStateInterface $form_state) {
 
    return $form['site_credits'];
  }

  /**
   * {@inheritdoc}
   */
  public function addOne(array &$form, FormStateInterface $form_state)
  {
    $users = $form_state->get('num_user');
    $add_user = $users + 1;
    $form_state->set('num_user', $add_user);
    
    $form_state->setRebuild();
  }


  /**
   * {@inheritdoc}
   */
  public function removeCallback(array &$form, FormStateInterface $form_state)
  {
    $users = $form_state->get('num_user');
    if ( $users > 1 )
    {
      $remove_user = $users - 1;
      $form_state->set('num_user', $remove_user);
    }
    
    $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array & $form, FormStateInterface $form_state) {
	
		$field = $form_state->getValues();
  
		$fields["field_uid"] = $field['field_uid'];
		$fields["field_role"] = $field['field_role'];
		$fields["field_status"] = $field['field_status'];
    $fields["field_user_emailid"] = $field['field_user_emailid'];


  }

  public function get_role_options(){
    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'workspace', 'status' => 1]);
    foreach($nodes as $node){
      $field_users = $node->get('field_users')->referencedEntities();
     
      foreach($field_users as $field_user) {
        dump($field_user);   
        print $field_user->label();
      }
      $options_array = [];
      $field_name = $field_users;
      $definitions = \Drupal::service('entity_field.manager')->getFieldDefinitions($this->entityTypeId, $this->bundle());
  dump($definitions);exit;
      if (isset($definitions[$field_name])) {
        $options_array = $definitions[$field_name]->getSetting('allowed_values');
      }
    
    
  }

}
 /**
   * {@inheritdoc}
   */
  public function getFieldDefinitions() {
    if (!isset($this->fieldDefinitions)) {
      $this->fieldDefinitions = \Drupal::service('entity_field.manager')->getFieldDefinitions($this->entityTypeId, $this->bundle());
    }
    return $this->fieldDefinitions;
  }
}